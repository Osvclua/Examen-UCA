#include <cstdlib>
#include <cstdio>
#include <climits>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/stat.h>
#include <string>
#include <cstring>
#include <iostream>
#include <iomanip>
#define CLAVE "/home"

using namespace std;								