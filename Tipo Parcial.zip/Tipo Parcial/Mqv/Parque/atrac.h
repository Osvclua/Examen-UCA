#ifndef _atrac_h
#define _atrac_h
#define llegaPas "LP"
#define salePas "SP"
#define fin "FIN"
#endif
